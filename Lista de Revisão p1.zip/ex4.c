#include <stdio.h>
#include <stdlib.h>

int main ()
{
    int n, m, h=0, end, dado;
    int *memoria=NULL;

    printf("Quantos bytes tera sua memoria: ");
    scanf("%d", &n);

    memoria = (int*) malloc (n*sizeof(int));

    do
    {
        printf("O que deseja fazer?\n\n");
        printf("1. Inserir um dado em um determinado endere�o.\n");
        printf("2. Consultar um dado contido em determinado endereco.\n");
        printf("3. Sair.\n");
        scanf("%d", &m);
        switch (m)
        {
        case 1:
            {
                printf("Qual endere�o vc deseja inserir um dado?\n");
                scanf("%d", &end);
                printf("Numero: ");
                scanf("%d", &dado);
                memoria[end-1] = dado;
                printf("\n\n");
            }
        break;
        case 2:
            {
                printf("Qual endereco deseja consultar?\n");
                scanf("%d", &end);
                printf("%d", memoria[end-1]);
                printf("\n\n");
            }
        break;
        default: h=1;
        }
    } while (h == 0);

    return 0;
}
