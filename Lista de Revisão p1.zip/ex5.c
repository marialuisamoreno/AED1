#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int main ()
{
    char file1[100], file2[100];
    FILE *f1, *f2;
    int c;

    printf("Digite o nome do primeiro arquivo: ");
    gets(file1);
    printf("Digite o nome do segundo arquivo: ");
    gets(file2);

    if ((f1 = fopen(file1,"rt")) == NULL)
    {
        printf("N�o eh possivel abrir o arquivo\n");
        exit(1);
    }

    if ((f2 = fopen(file2,"wt")) == NULL)
    {
        printf("N�o eh possivel abrir o arquivo\n");
        exit(1);
    }

    f1 = fopen(file1,"rt");
    f2 = fopen(file2,"wt");

    while ((c = fgetc(f1)) != EOF)
    {
        fputc(toupper(c), f2);
        printf("%c", c);
    }

    fclose(f1);
    fclose(f2);

    return 0;
}

