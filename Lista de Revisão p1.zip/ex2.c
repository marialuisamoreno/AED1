#include <stdio.h>
#include <stdlib.h>

char situacao(float p1, float p2, float p3, int faltas, int aulas, float *media);

int main ()
{
    float p1, p2, p3;
    int faltas;
    int aulas;
    float media;

    printf("Digite a nota da p1: ");
    scanf("%f", &p1);
    printf("\nDigite a nota da p2: ");
    scanf("%f", &p2);
    printf("\nDigite a nota da p2: ");
    scanf("%f", &p3);
    printf("\nDigite o numero de faltas: ");
    scanf("%d", &faltas);
    printf("\nDigite o numero de aulas: ");
    scanf("%d", &aulas);

    if (situacao(p1, p2, p3, faltas, aulas, &media) == 'A')
        printf("\nAprovado!\n");
    else if (situacao(p1, p2, p3, faltas, aulas, &media) == 'R')
        printf("\nReprovado!\n");
    else if (situacao(p1, p2, p3, faltas, aulas, &media) == 'F')
        printf("\nReprovado por falta!\n");
    else printf("\nErro\n");

    return 0;
}

char situacao(float p1, float p2, float p3, int faltas, int aulas, float *media)
{
    float media_faltas;

    media_faltas = (((float)faltas)/((float)aulas)*100);
    *media = (p1 + p2 + p3)/3;

    if (media_faltas <= 25.00)
    {
        if (*media >= 6.0) return 'A';
        else if (*media < 6.0) return 'R';
    }
    else return 'F';
}
