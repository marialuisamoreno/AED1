#include <stdio.h>
#include <stdlib.h>

int main()
{
    int *A=NULL, *B=NULL;
    int i, k=0, a;
    char c;
    FILE *arq;

    printf("Digite o tamanho de A: ");
    scanf("%d", &a);

    arq = fopen("arquivo.txt","w+");
    A = (int*)malloc(a*sizeof(int));
    B = (int*)malloc(a*sizeof(int));

    printf("Digite os valores de A:\n");
    for (i=0; i<a; i++)
    {
        scanf("%d", &A[i]);
        fprintf(arq,"%d\n", A[i]);
    }
    fclose(arq);
    arq = fopen("arquivo.txt","r");

    i=0;
    while(!feof(arq))
    {
        fscanf(arq,"%d",&B[i]);
        i++;
    }
    fclose(arq);

    for (i=0; i<a; i++)
    {
        if(A[i]!=B[i])
            k=1;
    }

    if(k==0)
        printf("\nGravado corretamente.");
    else printf("\nDeu ruim.");

    printf("\nB\n");
    arq = fopen("arquivo.txt","r");

    c = getc(arq);
    while (!feof(arq))
    {
        printf("%c",c);
        c = getc(arq);
    }
    return 0;
}


