#include <stdio.h>
#include <stdlib.h>

///Este algoritmo possui complexidade quadr�tica
int main ()
{
    int *S;
    int s, i, j, x, k, aux=0;

    printf("Digite o elemento X: ");
    scanf("%d", &x);

    printf("Digite o numero de elementos do conjunto S: ");
    scanf("%d", &s);

    S = malloc(s*sizeof(int));

    for (i=0; i<s; i++)
        scanf("%d", &S[i]);

    for (i=0; i<s; i++)
    {
        for (j=0; j<s; j++)
        {
            k = S[i] + S[j];
            if (k == x)
            {
                printf("Existe uma soma de dois elementos cuja soma e exatamente x!\n");
                return 0;
            }
        }
        aux++;
    }

    if (aux == s) printf("Nao existe uma soma!\n");

    return 0;
}
