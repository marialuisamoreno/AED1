
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct C
{
    char ch;
    struct C *prox;
}C;

typedef struct
{
    C *inicio;
    C *fim;
    int qtd;
}Lista;

void inicializa (Lista *lista);
void insere (Lista *lista, char c);
void imprimir (Lista *lista);

int main ()
{
    int i, tam;
    char string1[100];
    Lista lista;
    inicializa(&lista);

    printf("Digite a string: ");
    fflush(stdin);
    gets(string1);

    tam = strlen(string1);
    for (i=0; i<tam; i++)
    {
        if (string1[i] == '0' || string1[i] == '1' || string1[i] == '2' || string1[i] == '3' || string1[i] == '4' || string1[i] == '5' || string1[i] == '6' || string1[i] == '7' || string1[i] == '8' || string1[i] == '9')
            insere(&lista, string1[i]);
        else
            printf("%c", string1[i]);
    }

    imprimir(&lista);

    return 0;
}

void inicializa (Lista *lista)
{
    lista->inicio = NULL;
    lista->fim = NULL;
    lista->qtd = 0;
}

void insere (Lista *lista, char c)
{
    C *novo;
    novo = (C*) malloc(sizeof(C));

    novo->ch = c;
    novo->prox = NULL;

    if (lista->inicio == NULL)
    {
        lista->inicio = novo;
        lista->fim = novo;
    }

    else
    {
        lista->inicio->prox = novo;
        lista->inicio = novo;
    }

    lista->qtd++;
}

void imprimir (Lista *lista)
{
    C *percorre;
    percorre = lista->fim;

    while (percorre != NULL)
    {
        printf("%c", percorre->ch);
        percorre = percorre->prox;
    }
}
