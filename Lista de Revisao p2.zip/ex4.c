#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct C
{
    char ch;
    struct C *anterior;
}C;

typedef struct
{
    C *topo;
    int qtd;
}Pilha;

void inicializa (Pilha *pilha);
void empilha (Pilha *pilha, char c);
void imprime (Pilha *pilha, char string2[], int tam);

int main ()
{
    int i, tam;
    char string1[1000], string2[1000];
    Pilha *pilha;
    pilha = (Pilha*) malloc(sizeof(Pilha));
    inicializa(pilha);

    printf("Digite a string: ");
    gets(string1);

    tam = strlen(string1);
    for (i=0; i<tam; i++)
    {
        if (string1[i] != ' ' && string1[i] != '\n')
            empilha(pilha, string1[i]);
    }

    printf("\nOrdem inversa: ");
    imprime(pilha, string2, tam);
    printf("%s\n\n", string2, tam);

    if (strcmp(string1, string2) == 0)
        printf("Eh palindroma!\n");
    else
        printf("Nao eh palindroma!\n");

    return 0;
}

void inicializa (Pilha *pilha)
{
    pilha->topo = NULL;
    pilha->qtd = 0;
}

void empilha (Pilha *pilha, char c)
{
    C *novo;
    novo = (C*)malloc(sizeof(C));

    novo->ch = c;

    novo->anterior = pilha->topo;
    pilha->topo = novo;

    pilha->qtd++;
}

void imprime (Pilha *pilha, char string2[], int tam)
{
    int i=0;
    C *percorre;
    percorre = pilha->topo;

    while (percorre != NULL && i != tam)
    {
        string2[i] = percorre->ch;
        percorre = percorre->anterior;
        i++;
    }
}
