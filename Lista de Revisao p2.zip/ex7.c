#include <stdio.h>
#include <stdlib.h>

typedef struct conjunto
{
    int conteudo;
    struct conjunto *prox, *ant;
}conjunto;

typedef struct
{
    conjunto *inicio;
    conjunto *fim;
    int qtd;
}Lista;

void inicializa (Lista *lista);
void inserir (Lista *lista, int dado);
void soma (Lista *listaA, Lista *listaB);

int main ()
{
    int a, b, n, i;
    Lista listaA, listaB;
    inicializa(&listaA);
    inicializa(&listaB);

    printf("Tamanho do conjunto A: ");
    scanf("%d", &a);
    printf("\nTamanho do conjunto B: ");
    scanf("%d", &b);

    printf("Elementos de A\n");
    for (i=0; i<a; i++)
    {
        scanf("%d", &n);
        inserir(&listaA, n);
    }

    printf("Elementos de B\n");
    for (i=0; i<b; i++)
    {
        scanf("%d", &n);
        inserir(&listaB, n);
    }

    printf("\nSoma: ");
    soma(&listaA, &listaB);


}

void inicializa (Lista *lista)
{
    lista->inicio = NULL;
    lista->fim = NULL;
    lista->qtd = 0;
}

void inserir (Lista *lista, int dado)
{
    conjunto *novo;
    novo = (conjunto*)malloc(sizeof(conjunto));

    if (lista->qtd == 0)
    {
        novo->conteudo = dado;
        novo->ant = lista->inicio;
        novo->prox = lista->fim;
        lista->inicio = novo;
        lista->fim = novo;
        lista->qtd++;
    }

    else
    {
        novo->conteudo = dado;
        novo->ant = lista->fim;
        novo->prox = NULL;
        lista->fim->prox = novo;
        lista->fim = novo;
        lista->qtd++;
    }
}

void soma (Lista *listaA, Lista *listaB)
{
    conjunto *percorre;
    percorre = listaA->inicio;

    while (percorre != NULL)
    {
        printf("%d ", percorre->prox->conteudo);
        percorre = percorre->prox;
    }

    percorre = listaB->inicio;
    while (percorre != NULL)
    {
        printf("%d ", percorre->prox->conteudo);
        percorre = percorre->prox;
    }
}
