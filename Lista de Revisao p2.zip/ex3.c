#include <stdio.h>
#include <stdlib.h>

typedef struct item
{
    int conteudo;
    struct item *prox;
}item;

typedef struct
{
    item *inicio;
    item *fim;
    int qtd;
}Lista;

void inicializar (Lista *lista);
void inserir (Lista *lista, int n);
void imprime (Lista *lista);

int main ()
{
    int i, n;
    Lista lista;
    inicializar(&lista);

    printf("Digite os itens:\n");

    for (i=0; i<10; i++)
    {
        scanf("%d", &n);
        inserir(&lista, n);
    }

    printf("\nElementos pares: ");
    imprime(&lista);
}

void inicializar (Lista *lista)
{
    lista->inicio = NULL;
    lista->fim = NULL;
    lista->qtd = 0;
}

void inserir (Lista *lista, int n)
{
    item *novo;
    novo = (item*)malloc(sizeof(item));

    novo->prox = NULL;
    novo->conteudo = n;

    if (lista->inicio == NULL)
    {
        lista->inicio = novo;
        lista->fim = novo;
    }

    else
    {
        lista->fim->prox = novo;
        lista->fim = novo;
        novo->prox = NULL;
    }

    lista->qtd++;
}

void imprime (Lista *lista)
{
    int i=0;
    item *percorre;
    percorre = lista->inicio;

    while (percorre != NULL)
    {
        if (i%2 == 0)
        {
            printf("%d ", percorre->conteudo);
        }
        i++;
        percorre = percorre->prox;
    }
}
