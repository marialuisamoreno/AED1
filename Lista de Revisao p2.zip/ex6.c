#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Site
{
    char nome[100];
    char endereco[1000];
    struct Site *prox;
    int prioridade;
}Site;

typedef struct Fila
{
    Site *inicio;
    Site *fim;
    int tamanho;
}Fila;

void inserir_fim(Fila *f, char nominho[], char enderecinho[]);
void inicializar(Fila *f);
void imprime(Fila *f);
void remover(Fila *f);

int main ()
{
    int i;
    char nome[100], endereco[1000];
    Fila cont;
    inicializar(&cont);

    for (i=0; i<3; i++)
    {
        printf("\nNome [%d]: ", i+1);
        fflush(stdin);
        gets(nome);
        printf("End: ");
        fflush(stdin);
        gets(endereco);
        inserir_fim(&cont, nome, endereco);
    }

    imprime(&cont);

    return 0;
}

void inicializar (Fila *f)
{
    f->inicio = NULL;
    f->fim = NULL;
    f->tamanho = 0;
}

void inserir_fim (Fila *f, char nominho[], char enderecinho[])
{
    int n=0;
    Site *percorre;
    percorre = f->inicio;

    while (percorre != NULL)
    {
        if (strcmp(percorre->endereco, enderecinho) == 0)
        {
            percorre->prioridade++;
            n=1;
            break;
        }
        percorre = percorre->prox;
    }

    if (n == 0)
    {
        Site *novo = malloc(sizeof(Site));
        f->tamanho++;
        novo->prox = NULL;

        strcpy(novo->nome, nominho);
        strcpy(novo->endereco, enderecinho);
        novo->prioridade = 0;

        if(f->inicio == NULL)
        {
            f->inicio = novo;
            f->fim = novo;
        }

        else
        {
            f->fim->prox = novo;
            f->fim = novo;
        }
    }
}

void imprime (Fila *f)
{
    int p;
    Site *percorre;
    p = f->inicio->prioridade;
    percorre = f->inicio;

    while(percorre != NULL)
    {
        if (percorre->prioridade > p)
        {
            p = percorre->prioridade;
        }
        percorre = percorre->prox;
    }

    percorre = f->inicio;
    while (percorre != NULL)
    {
        if (percorre->prioridade == p)
        {
            printf("Endereco mais visitado\n");
            printf("Nome: %s", percorre->nome);
            printf("\nEndereco: %s\n", percorre->endereco);
        }
        percorre = percorre->prox;
    }
}

